---
name: project-skeleton-ai-workflow
description: v10.0.0 GOLD-SKELETON 経路 (2026-05-27 確定)。canonical/KTX311-gold-baseline.html を唯一の起点として AI 判断で内容を埋め込む。render.py 経路は禁止
metadata: 
  node_type: memory
  type: project
  originSessionId: 014e9285-7d85-4415-ad84-3c4573a288e8
---

# スケルトン + AI 判断 経路（v10.0.0 GOLD-SKELETON・2026-05-27 確定）

## 経緯

JSON-render 経路（render.py 経由）で gold quality 到達せず。視覚品質（basis ジャンプリンク・
体系ツリー/マインドマップの見切れ・C-3 escape バグ・学説対立レイアウト・総合フローチャート）の
改善が JSON 経路の修正では限界。

303-gold を起点とした初期スケルトン経路で 311 を確定第 1 号として gold quality 到達後、
311 自身を新 baseline に昇格し v10.0.0 GOLD-SKELETON として正式化。

## 確定方針

**canonical/KTX311-gold-baseline.html を唯一の起点として clone → AI 判断で問題内容を埋め込む**

1. `canonical/KTX311-gold-baseline.html` を Read（構造参考の唯一の正典）
2. PowerShell `Copy-Item` で対象ファイル名にコピー
3. コピー直後に本文を**空文字列で初期化**（content-independence 確保）
4. HEAD `:root{}` を配色 V2 ([[project-palette-v2]]) で更新
5. HEADER / PART A / PART B / A-3 basis / SVG / PART C / PART D / footer-spec を
   **section-by-section** で問題固有内容に差替（各 Edit 30〜50KB 以下）
6. SVG 重なり機械検査（[[feedback-svg-box-overlap]]）
7. 配信前検証：`python scripts/validate-tx-gold.py <出力ファイル>`
8. G1〜G15 ALL PASS 確認 + 視覚確認 → present_files

## 絶対禁止事項

- **`python scripts/render.py {問題番号}` 実行**：JSON-render 結果が target ファイルを
  上書きし WIP 作業全消失（過去事故あり）
- **canonical/KTX311-gold-baseline.html および KTX301.html の本文・解説・判例引用の
  文字列コピー**（AP-42 違反・G12/G13 で機械検出）
- **`outputs/*/` 配下の既存 HTML を別問題生成の template として使用**（AP-42 違反の温床）
- **ヘッダー／フッター表示テキストに配色 Concept 文言を残す**（G8 で機械検出）

## v10.0.0 鉄則

**Why:** 2026-05-27 セッションで render.py 経路の限界を確認、303-gold スケルトン経路で 311 を
新仕様で確定。311 自身が gold quality に到達したため、新たな baseline として正式化。
ユーザーは「視覚品質 = 311 baseline 同等」を最終判定基準とする。

**How to apply:**
- 既存 outputs/*.html を **絶対に template にしない**
- 唯一許可される起点：`canonical/KTX311-gold-baseline.html`
- 補助：`canonical/KTX301.html`（v9.x 系構造参考のみ・本文コピーは AP-42 違反）
- 各 section は baseline の構造（タグ・class・id・ネスト順序・CSS/JS）を **逐語コピー**、
  本文・解説・判例引用・SVG 内テキストは問題 PDF + AI 判断から新規鋳造
- AI 判断が必要な領域：
  - 配色 Concept ([[project-palette-v2]])
  - SVG レイアウト（座標は 311 baseline のまま、テキスト・色 class のみ差替）
  - basis cards の選定（本問の主要条文・判例 5 枚以内）
  - C-4 学説対立の 2 主要説選定

## 視覚確認重視

- ユーザーは 311 baseline と並べてブラウザで比較し、レイアウト・色合い・密度を最終判定
- `validate-tx-gold.py` の G1〜G15 PASS は **必要条件ではあるが十分条件でない**

## 関連参照

- baseline 昇格詳細：[[project-311-finalized]]
- 配色 V2：[[project-palette-v2]]
- SVG 重なり禁止：[[feedback-svg-box-overlap]]
- Semantic exception：[[feedback-semantic-exceptions]]
- 検証スクリプト：`scripts/validate-tx-gold.py`（G1〜G15）
- コマンド：`.claude/commands/new-tx.md`／`.claude/commands/batch-tx.md`
