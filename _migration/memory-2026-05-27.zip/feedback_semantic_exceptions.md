---
name: feedback-semantic-exceptions
description: 配色 V2 で palette 越境を許容する慣習色（✓ 緑・🏆 金）のルール
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2d4239b0-df19-4313-9814-46fed83d05fe
---

# Semantic color exceptions（配色 V2 越境許容ルール）

[[project-palette-v2]] では各パターン 27 色から選定が原則だが、以下 2 領域では認知慣習を優先して palette 越境を許容する。

## 1. 正解 ✓ 表示（緑）

- **対象変数**：`--recall-correct` / `--recall-correct-light`
- **慣習**：✓ マークは緑（universal usability）
- **適用**：P1（ピンク）・P3（パープル）パターン採用時、P2 の緑色を借用する
  - P1 → #438B48 (P2 #19) / #7BA980 (P2 #25)
  - P3 → 同上
- **理由**：ピンクや紫を「正解」とすると誤解の元（パターン主役色との分離が必要）

## 2. ARENA 達成 🏆 表示（金）

- **対象**：`.recall-arena .section-title .sec-icon` / `.counter-current` / `.counter-fill` background gradient
- **使用 hex**：`#ffd54f`（gold-amber）・`#ffaa00`（orange gradient stop）
- **慣習**：medal/trophy の認知慣習（universal achievement signal）
- **適用**：全パターンで保持（palette に金/黄系がある P2 #FFDF76 等とは別概念）

## Why このルールを設けるか

**Why:** 2026-05-27 セッションで 311 を P1 配色に切替えた際、✓ マーク用の緑が palette に存在しないことを発見。AI が pink-only で塗ると正解認知が悪化する。ユーザー判断で「semantic exception は越境 OK」と確定。

**How to apply:**
- 新規 TX 生成時、recall-correct 系は常に P2 緑（#438B48 / #7BA980）を使う
- ARENA gold（#ffd54f / #ffaa00）は inline hex のまま保持（CSS 変数化しない）
- 不正解（recall-incorrect）は pattern 主役色から派生してよい（例：P1 なら #C05191 マゼンタ等）
- footer-spec / exam-meta の Concept 説明では「Semantic exception: ✓ P2 緑借用」と明記
