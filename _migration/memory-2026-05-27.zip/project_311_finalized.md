---
name: project-311-finalized
description: 刑TX311 を v10.0.0 GOLD-SKELETON baseline に昇格 (2026-05-27)。canonical/KTX311-gold-baseline.html が新規 TX 生成の唯一の起点
metadata: 
  node_type: memory
  type: project
  originSessionId: 014e9285-7d85-4415-ad84-3c4573a288e8
---

# 刑TX311 baseline 昇格状態（2026-05-27）

## 問題メタ

- 出力ファイル：`outputs/tx/刑TX/刑TX311.html` (262 KB / 4156 行)
- **canonical baseline**：`canonical/KTX311-gold-baseline.html`（新規 TX 生成の唯一の起点）
- 出典：共通H29-16（不法原因給付と横領）
- 正答率：85% → P1 適用
- 難度：★☆☆ 易
- 出題形式：single-choice-5
- 正解：肢5（ウ・オ）

## 適用仕様（v10.0.0 GOLD-SKELETON）

1. **スケルトン経路**：`canonical/KTX311-gold-baseline.html` から clone → 本文空文字列初期化 →
   section-by-section で問題内容を新規鋳造（[[project-skeleton-ai-workflow]]）
2. **配色 V2**：P1 27 色中 18 色採用（[[project-palette-v2]]）
   - Concept：上品な大人ピンク × ローズ × 青コントラスト
   - 主色：マゼンタ #C05191 + モーブ #CF82AD + 薄ピンク #EDBFBF + クリーム #F2E8CB + 青 #005FAA
3. **Semantic exception**：✓ 緑は P2 #438B48 借用、🏆 金は ARENA 慣習保持
   ([[feedback-semantic-exceptions]])
4. **SVG 重なり機械検査**：rect/ellipse の bounding box 全ペア AABB 衝突判定
   ([[feedback-svg-box-overlap]])
5. **ヘッダー／フッター本文に配色記載なし**：`:root{}` と footer-spec hidden feature-tag
   のみで配色情報を管理

## feature-tag（v10.0.0）

```
TX v10.0.0 GOLD-SKELETON
ktx311-baseline
palette-v2-ai-selection
svg-overlap-checked
content-independence
jp-prefix-naming
```

## 検証

`python scripts/validate-tx-gold.py outputs/tx/刑TX/刑TX311.html`
→ G1〜G15 ALL PASS（2026-05-27 確認済）

## 関連参照

- WIP（バックアップ）：`_experimental/刑TX311-wip-gold-skeleton.html`
- 問題 PDF：`inputs/tx-pdfs/311.pdf`
- handoff 文書：`docs/PHASE-14-311-GOLD-SKELETON-WIP-HANDOFF.md`

## 次のステップ

312 以降は `/new-tx inputs/tx-pdfs/312.pdf` または `/batch-tx 312` で
v10.0.0 GOLD-SKELETON 経路により連続生成可能。
