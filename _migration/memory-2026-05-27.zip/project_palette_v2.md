---
name: project-palette-v2
description: 配色パターン V2 (2026-05-27 確定)。P1/P2/P3 各 27 色から AI 判断で問題ごとに異なる Concept を組立てる新仕様。サブパレット概念は廃止
metadata: 
  node_type: memory
  type: project
  originSessionId: 2d4239b0-df19-4313-9814-46fed83d05fe
---

# 配色パターン V2（2026-05-27 確定）

## 選定基準（正答率帯による P1/P2/P3 振分け・spec §32 継承）

| パターン | 正答率帯 | テーマ名 | 出典 |
|:-:|:-:|:--|:--|
| **P1** | ≥ 60% | ピンクを使った可愛い配色 | ingectar-e Color Pickup #16 |
| **P2** | 40〜60% | グリーンを使った可愛い配色 | ingectar-e Color Pickup #22 |
| **P3** | < 40% | ロマンティックなパープル配色 | ingectar-e PURPLE |

## AI 判断の中核ルール

- **27 色（=9 サブパレット×3色）から AI が問題ごとに自由選定**
- **サブパレット単位の選択は廃止**：1〜27 色のうち何色でも組合せ可
- **Concept は問題ごとに別**：同じ P1 でも 311 と他問題で Concept を変える
- **CSS 変数 ~20 個（--accent / --mid / --light / --base / --soft / --bg-dark / --accent-3 / --accent-soft / --border-mid / --kp-text-color ＋ v9.3.0 派生色 10）への役割割当ても AI 判断**

## AI 判断指標（Concept 設計の判定軸）

1. **テーマの重さ**：道徳論点・重罪 → 落ち着き寄り／日常論点 → 爽やか
2. **難度（★）**：易 → 明るめ／難 → 重め
3. **罪名イメージ**：財産罪 → ピンク系優先／身体犯 → 暖系／手続 → クール
4. **正解の意外性**：罠多い問題 → コントラスト強／素直 → 同系統調和

## 旧システムからの変更点

**Why:** 紅蓮/群青蘭/黎明 の 3 流派固定 + HSL 派生は AI 判断の自由度が低く、問題ごとの差別化ができなかった。ingectar-e カタログ（各パターン 27 色）を採用することで、同じ P1 でも問題ごとに全く別 Concept を生成可能になった。

**How to apply:**
- 新規 TX 生成時：まず正答率帯から P1/P2/P3 を決定（自動）→ 問題テーマから Concept を AI 判断 → 27 色から ~20 個ピックして CSS 変数へ割当て → footer-spec に「P1 ピンクを使った可愛い配色 (AI 自由選定)」と表記
- カタログ参照：[[reference-ingectar-palette]] に 81 色（27×3）の hex 一覧あり
- Semantic exception：[[feedback-semantic-exceptions]] で ✓ 緑・🏆 金の palette 越境ルールを参照

## 311 への適用例（参考）

- 正答率 85% → P1
- テーマ：不法原因給付と横領（道徳論点・★☆☆ 易）
- Concept：上品な大人ピンク × ローズ × 青コントラスト
- 採用色：マゼンタ #C05191 + モーブ #CF82AD + 薄ピンク #EDBFBF + クリーム #F2E8CB + 青 #005FAA + 14 色

詳細は [[project-311-finalized]] 参照。
