---
name: feedback-svg-box-overlap
description: SVG マインドマップ/フローチャート生成時のボックス重なり禁止。座標を機械的に検査してから出力する
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 014e9285-7d85-4415-ad84-3c4573a288e8
---

# SVG ボックス重なり禁止（2026-05-27 確定）

TX の SVG 系図表（マインドマップツリー・放射マインドマップ・C-5 総合フローチャート）で、`<rect>` / `<ellipse>` / `<polygon>` の bounding box が他のボックスと重なってはならない。

## Why

2026-05-27、刑TX311 の論点マインドマップ放射図 (viewBox `0 0 1500 1180`) で、中央下の「本問の論点」ボックス (x=410–1090, y=1060–1140) が左右のサブ要素「最大判昭45.10.21」(x=370–590, y=1068–1112) と「反射的効果論前提」(x=920–1120, y=1068–1112) と完全に重なる事故が発生。ユーザーがブラウザ視覚確認で発見。

303-gold のスケルトンから座標を流用しただけでは、問題ごとに異なるサブ要素のラベル長や配置で重なりが発生する。

## How to apply

### 生成時の必須手順

1. **SVG 出力前に座標を表で書き出す**：各ボックスの `(cx, cy, width, height)` から bounding box `(x_min, x_max, y_min, y_max)` を計算
2. **総当たり衝突検査**：全ペアで `x_min_A < x_max_B AND x_max_A > x_min_B AND y_min_A < y_max_B AND y_max_A > y_min_B` が成立しないことを確認
3. **マージン 16px 以上**：重なりがなくても 16px 未満の隙間は視認上窮屈なので避ける
4. **viewBox の縦余裕**：放射マインドマップは最下端の正解表示まで含めて `viewBox` 高さに 60px 以上の余白を確保

### 重なりが見つかったときの優先順位

1. viewBox を拡張（最も安全・他要素への影響なし）
2. 中心から放射する要素を更に外側へ
3. ラベルを短縮（最後の手段・本文情報を削るので注意）

### 既存 SVG レビュー時のチェックリスト

- 体系ツリー（mindmap-tree）：L0/L1/L2/L3 と issue box の bounding box 全ペア
- 論点マインドマップ放射（mindmap-radial）：中心ellipse・7主要枝・各枝のサブ要素・本問の論点・正解 text
- C-5 総合フローチャート（flow-svg）：START/decision/chip/end の全ボックス

## 関連参照

- 配色 V2 適用例：[[project-311-finalized]]
- スケルトン経路：[[project-skeleton-ai-workflow]]（座標を逐語流用しても問題依存の差で破綻し得る）
